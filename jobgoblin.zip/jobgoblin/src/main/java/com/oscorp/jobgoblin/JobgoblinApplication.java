package com.oscorp.jobgoblin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JobgoblinApplication {
	public static void main(String[] args) {
		SpringApplication.run(JobgoblinApplication.class, args);
	}

}
